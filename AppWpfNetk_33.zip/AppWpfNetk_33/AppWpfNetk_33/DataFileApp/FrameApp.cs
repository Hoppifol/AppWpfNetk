﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace AppWpfNetk_33.DataFileApp
{
    internal class FrameApp
    {
        /// <summary>
        /// Логика взаимодействия между страницами
        /// </summary>
        public static Frame frmObj;
    }
}
