﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppWpfNetk_33.DataFileApp
{
    internal class OdbConnectHelper
    {
        public static AppWpfNetk33Entities1 entObj;
    }
}
